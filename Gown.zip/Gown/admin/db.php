<?php
$con = mysqli_connect("localhost","root","","gowns") or die(mysql_error());

?>